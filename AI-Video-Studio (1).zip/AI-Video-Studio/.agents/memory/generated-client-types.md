---
name: Generated client TypeScript
description: A TypeScript compiler setting required by the workspace's generated browser API client.
---

The generated API client uses `Headers.entries()`, so its composite TypeScript package must include both `dom` and `dom.iterable` libraries.

**Why:** Orval codegen can succeed while the workspace library build fails if iterable DOM types are omitted.

**How to apply:** If generated client typechecking reports that `Headers.entries` does not exist, inspect the client package's `compilerOptions.lib` before changing generated output.