---
name: Local media workflow paths
description: How generated media paths behave when the API runs as an artifact workflow.
---

The API workflow starts with `artifacts/api-server` as its working directory, while shell checks may run from the workspace root. Resolve local generated media relative to the current directory only when it is already the API artifact; otherwise include the artifact path explicitly.

**Why:** A workspace-root assumption created a nested `artifacts/api-server/artifacts/api-server` media directory during the first end-to-end render.

**How to apply:** Keep the generated-media root configurable with `FRAMEWISE_MEDIA_ROOT`, and make the default work from both the artifact workflow and workspace-root commands.