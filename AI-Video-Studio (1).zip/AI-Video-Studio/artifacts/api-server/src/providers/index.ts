export type ProviderJobKind = "video" | "voiceover" | "captions" | "export";

export type ProviderJobInput = {
  projectId: number;
  sceneId?: number | null;
  width?: number;
  height?: number;
  includeCaptions?: boolean;
  includeMusic?: boolean;
};

export type ProviderJobResult = {
  status: "queued" | "processing" | "complete" | "failed";
  progress: number;
  message: string;
  outputObjectPath?: string;
};

export interface MediaProvider {
  readonly name: string;
  readonly kind: ProviderJobKind;
  run(input: ProviderJobInput): Promise<ProviderJobResult>;
}

class NotConfiguredProvider implements MediaProvider {
  constructor(
    public readonly kind: ProviderJobKind,
    public readonly name: string,
  ) {}

  async run(): Promise<ProviderJobResult> {
    return {
      status: "queued",
      progress: 0,
      message: `${this.name} is a provider seam. Connect an implementation before running jobs.`,
    };
  }
}

export const mediaProviders: Record<ProviderJobKind, MediaProvider> = {
  video: new NotConfiguredProvider("video", "open-source-video"),
  voiceover: new NotConfiguredProvider("voiceover", "open-source-tts"),
  captions: new NotConfiguredProvider("captions", "ffmpeg-whisper"),
  export: new NotConfiguredProvider("export", "ffmpeg-compositor"),
};

export function getMediaProvider(kind: ProviderJobKind, requestedName?: string) {
  const provider = mediaProviders[kind];
  if (requestedName && requestedName !== "ready-to-connect") {
    return { ...provider, name: requestedName };
  }
  return provider;
}