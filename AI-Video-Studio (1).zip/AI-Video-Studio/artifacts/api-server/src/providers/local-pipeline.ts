import { mkdir, unlink, writeFile } from "node:fs/promises";
import path from "node:path";
import { spawn } from "node:child_process";
import { and, asc, desc, eq } from "drizzle-orm";
import { db } from "@workspace/db";
import {
  assetsTable,
  jobsTable,
  projectsTable,
  scenesTable,
} from "@workspace/db/schema";

const workingDirectory = process.cwd();
const defaultMediaRoot =
  path.basename(workingDirectory) === "api-server"
    ? path.join(workingDirectory, "generated-media")
    : path.join(workingDirectory, "artifacts", "api-server", "generated-media");
export const mediaRoot = path.resolve(process.env.FRAMEWISE_MEDIA_ROOT ?? defaultMediaRoot);

const mediaUrl = (relativePath: string) => `/api/media/${relativePath.split(path.sep).join("/")}`;
const localMediaPath = (objectPath: string | null) => {
  if (!objectPath?.startsWith("/api/media/")) return null;
  return path.join(mediaRoot, objectPath.slice("/api/media/".length));
};
const voices = new Set(["en-us", "en", "en+f2", "en+f3", "en+f4", "en+f5"]);

export type EpisodeOptions = {
  projectId: number;
  jobId: number;
  voice: string;
  includeCaptions: boolean;
  includeMusic: boolean;
};

type SceneOutput = {
  sceneId: number;
  duration: number;
  clipPath: string;
  voicePath: string;
  captionPath: string;
  captionText: string;
};

function safeVoice(input: string) {
  return voices.has(input) ? input : "en-us";
}

function runCommand(command: string, args: string[]) {
  return new Promise<void>((resolve, reject) => {
    const child = spawn(command, args, { stdio: ["ignore", "ignore", "pipe"] });
    let stderr = "";
    child.stderr.on("data", (chunk) => {
      stderr += String(chunk);
    });
    child.once("error", reject);
    child.once("close", (code) => {
      if (code === 0) resolve();
      else reject(new Error(`${command} failed with code ${code}: ${stderr.slice(-1200)}`));
    });
  });
}

function timestamp(seconds: number) {
  const safe = Math.max(0, seconds);
  const hours = Math.floor(safe / 3600);
  const minutes = Math.floor((safe % 3600) / 60);
  const whole = Math.floor(safe % 60);
  const millis = Math.floor((safe - Math.floor(safe)) * 1000);
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(whole).padStart(2, "0")},${String(millis).padStart(3, "0")}`;
}

function makeCaptions(text: string, duration: number, offset = 0) {
  const words = text.trim().split(/\s+/).filter(Boolean);
  if (!words.length) return "";
  const perWord = duration / words.length;
  const lines: string[] = [];
  for (let index = 0; index < words.length; index += 7) {
    const chunk = words.slice(index, index + 7);
    const start = offset + index * perWord;
    const end = offset + Math.min(words.length, index + chunk.length) * perWord;
    lines.push(
      `${Math.floor(index / 7) + 1}\n${timestamp(start)} --> ${timestamp(end)}\n${chunk.join(" ")}\n`,
    );
  }
  return lines.join("\n");
}

async function updateJob(jobId: number, patch: Partial<typeof jobsTable.$inferInsert>) {
  await db.update(jobsTable).set(patch).where(eq(jobsTable.id, jobId));
}

async function createChildJob(
  projectId: number,
  kind: "video" | "voiceover" | "captions",
  sceneId: number,
) {
  const [job] = await db
    .insert(jobsTable)
    .values({
      projectId,
      sceneId,
      kind,
      provider: kind === "voiceover" ? "espeak-ng" : kind === "captions" ? "srt-from-voiceover" : "local-ffmpeg-motion",
      message: "Queued.",
    })
    .returning();
  return job;
}

async function createAsset(
  projectId: number,
  name: string,
  type: "video" | "audio" | "subtitle",
  mimeType: string,
  objectPath: string,
) {
  const [asset] = await db
    .insert(assetsTable)
    .values({ projectId, name, type, mimeType, objectPath, source: "generated" })
    .returning();
  return asset;
}

async function renderSceneClip(
  projectId: number,
  sceneId: number,
  position: number,
  duration: number,
  sourceAsset?: { path: string; type: "image" | "video" },
) {
  const relative = path.join(String(projectId), `scene-${sceneId}.mp4`);
  const output = path.join(mediaRoot, relative);
  await mkdir(path.dirname(output), { recursive: true });
  const palette = ["0x173f5f", "0x20639b", "0x3caea3", "0xf6d55c", "0xed553b"];
  const color = palette[position % palette.length];
  const fadeOutAt = Math.max(0.5, duration - 0.45);
  const input = sourceAsset
    ? sourceAsset.type === "image"
      ? ["-loop", "1", "-i", sourceAsset.path]
      : ["-stream_loop", "-1", "-i", sourceAsset.path]
    : ["-f", "lavfi", "-i", `color=c=${color}:s=720x1280:r=30`];
  const sourceFilter = sourceAsset
    ? "scale=720:1280:force_original_aspect_ratio=increase,crop=720:1280,"
    : "";
  await runCommand("ffmpeg", [
    "-y",
    ...input,
    "-t",
    String(duration),
    "-vf",
    `${sourceFilter}drawbox=x=48:y=48:w=624:h=1184:color=white@0.06:t=3,drawbox=x=80:y=980:w=560:h=4:color=white@0.55:t=fill,fade=t=in:st=0:d=0.45,fade=t=out:st=${fadeOutAt}:d=0.45`,
    "-c:v",
    "libx264",
    "-preset",
    "veryfast",
    "-pix_fmt",
    "yuv420p",
    "-an",
    output,
  ]);
  return { output, objectPath: mediaUrl(relative) };
}

async function synthesizeVoiceover(
  projectId: number,
  sceneId: number,
  voice: string,
  text: string,
) {
  const relative = path.join(String(projectId), `scene-${sceneId}.wav`);
  const output = path.join(mediaRoot, relative);
  await mkdir(path.dirname(output), { recursive: true });
  await runCommand("espeak-ng", ["-v", safeVoice(voice), "-s", "145", "-w", output, text || " "]);
  return { output, objectPath: mediaUrl(relative) };
}

async function muxScene(clipPath: string, voicePath: string, outputPath: string, duration: number) {
  await runCommand("ffmpeg", [
    "-y",
    "-i",
    clipPath,
    "-i",
    voicePath,
    "-filter_complex",
    `[1:a]apad,atrim=duration=${duration}[voice]`,
    "-map",
    "0:v",
    "-map",
    "[voice]",
    "-t",
    String(duration),
    "-c:v",
    "copy",
    "-c:a",
    "aac",
    "-shortest",
    outputPath,
  ]);
}

async function composeEpisode(
  projectId: number,
  jobId: number,
  scenes: SceneOutput[],
  includeCaptions: boolean,
  includeMusic: boolean,
  musicPath: string | null,
) {
  const directory = path.join(mediaRoot, String(projectId));
  const concatPath = path.join(directory, `concat-${jobId}.txt`);
  const captionPath = path.join(directory, `episode-${jobId}.srt`);
  const basePath = path.join(directory, `episode-${jobId}-base.mp4`);
  const finalPath = path.join(directory, `episode-${jobId}.mp4`);
  const muxed: string[] = [];
  let elapsed = 0;
  let allCaptions = "";

  for (const scene of scenes) {
    const muxedPath = path.join(directory, `scene-${scene.sceneId}-muxed.mp4`);
    await muxScene(scene.clipPath, scene.voicePath, muxedPath, scene.duration);
    muxed.push(muxedPath);
    if (includeCaptions) {
      const caption = makeCaptions(scene.captionText, scene.duration, elapsed);
      allCaptions += `${allCaptions ? `${allCaptions.trim()}\n\n` : ""}${caption}`;
    }
    elapsed += scene.duration;
  }

  await writeFile(concatPath, muxed.map((file) => `file '${file.replaceAll("'", "'\\''")}'`).join("\n"));
  await runCommand("ffmpeg", [
    "-y",
    "-f",
    "concat",
    "-safe",
    "0",
    "-i",
    concatPath,
    "-c",
    "copy",
    basePath,
  ]);

  if (includeCaptions) {
    await writeFile(captionPath, allCaptions);
  }

  const filters: string[] = [];
  if (includeCaptions) filters.push(`subtitles=${captionPath}:force_style='Alignment=2,MarginV=150,FontSize=18,Outline=2'`);
  if (includeMusic) {
    filters.push("format=yuv420p");
  }
  const args = ["-y", "-i", basePath];
  if (includeMusic) {
    if (musicPath) {
      args.push("-stream_loop", "-1", "-i", musicPath);
    } else {
      args.push("-f", "lavfi", "-i", `sine=frequency=220:sample_rate=44100:duration=${elapsed}`);
    }
  }
  if (filters.length) args.push("-vf", filters.join(","));
  if (includeMusic) {
    args.push(
      "-filter_complex",
      `[1:a]volume=0.035,atrim=duration=${elapsed}[music];[0:a][music]amix=inputs=2:duration=first:dropout_transition=2[mixed]`,
      "-map",
      "0:v",
      "-map",
      "[mixed]",
    );
  } else {
    args.push("-map", "0:v", "-map", "0:a");
  }
  args.push("-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "aac", "-movflags", "+faststart", finalPath);
  await runCommand("ffmpeg", args);

  await Promise.all(
    [...muxed, concatPath, basePath, ...(includeCaptions ? [captionPath] : [])].map((file) =>
      unlink(file).catch(() => undefined),
    ),
  );
  return { finalPath, objectPath: mediaUrl(path.join(String(projectId), `episode-${jobId}.mp4`)) };
}

async function runSceneSteps(
  projectId: number,
  scene: typeof scenesTable.$inferSelect,
  voice: string,
  options: { videoJobId?: number; voiceJobId?: number; captionJobId?: number },
) {
  const videoJob = options.videoJobId ? { id: options.videoJobId } : await createChildJob(projectId, "video", scene.id);
  const voiceJob = options.voiceJobId ? { id: options.voiceJobId } : await createChildJob(projectId, "voiceover", scene.id);
  const captionJob = options.captionJobId ? { id: options.captionJobId } : await createChildJob(projectId, "captions", scene.id);
  await updateJob(videoJob.id, { status: "processing", message: "Rendering local motion clip.", progress: 10 });
  const [sourceAsset] = scene.assetId
    ? await db
        .select()
        .from(assetsTable)
        .where(and(eq(assetsTable.id, scene.assetId), eq(assetsTable.projectId, projectId)))
    : [];
  const sourcePath = sourceAsset ? localMediaPath(sourceAsset.objectPath) : null;
  if (sourceAsset && !["image", "video"].includes(sourceAsset.type)) {
    throw new Error(`Scene ${scene.position + 1} asset must be an image or video.`);
  }
  const clip = await renderSceneClip(
    projectId,
    scene.id,
    scene.position,
    scene.duration,
    sourcePath && sourceAsset && (sourceAsset.type === "image" || sourceAsset.type === "video")
      ? { path: sourcePath, type: sourceAsset.type }
      : undefined,
  );
  const clipAsset = await createAsset(projectId, `Scene ${scene.position + 1} video`, "video", "video/mp4", clip.objectPath);
  await updateJob(videoJob.id, { status: "complete", progress: 100, outputAssetId: clipAsset.id, message: "Scene clip ready." });
  await updateJob(voiceJob.id, { status: "processing", message: "Synthesizing voice-over with espeak-ng.", progress: 10 });
  const voiceOutput = await synthesizeVoiceover(projectId, scene.id, voice, scene.voiceover);
  const voiceAsset = await createAsset(projectId, `Scene ${scene.position + 1} voice-over`, "audio", "audio/wav", voiceOutput.objectPath);
  await updateJob(voiceJob.id, { status: "complete", progress: 100, outputAssetId: voiceAsset.id, message: "Voice-over ready." });
  await updateJob(captionJob.id, { status: "processing", message: "Writing timed captions.", progress: 20 });
  const captionRelative = path.join(String(projectId), `scene-${scene.id}.srt`);
  const captionFile = path.join(mediaRoot, captionRelative);
  await writeFile(captionFile, makeCaptions(scene.voiceover, scene.duration));
  const captionAsset = await createAsset(projectId, `Scene ${scene.position + 1} captions`, "subtitle", "application/x-subrip", mediaUrl(captionRelative));
  await updateJob(captionJob.id, { status: "complete", progress: 100, outputAssetId: captionAsset.id, message: "Captions ready." });
  await db
    .update(scenesTable)
    .set({ status: "ready", previewUrl: clip.objectPath })
    .where(eq(scenesTable.id, scene.id));
  return {
    sceneId: scene.id,
    duration: scene.duration,
    clipPath: clip.output,
    voicePath: voiceOutput.output,
    captionPath: captionFile,
    captionText: scene.voiceover,
  };
}

export async function runEpisodePipeline(options: EpisodeOptions) {
  const scenes = await db
    .select()
    .from(scenesTable)
    .where(eq(scenesTable.projectId, options.projectId))
    .orderBy(asc(scenesTable.position));
  if (!scenes.length) throw new Error("Analyze the story into scenes before generating an episode.");
  const totalDuration = scenes.reduce((sum, scene) => sum + scene.duration, 0);
  if (totalDuration < 1) {
    throw new Error("Episode must be at least 1 second.");
  }
  if (totalDuration > 60.01) {
    throw new Error(`Episode is ${totalDuration.toFixed(1)} seconds. Reduce scene durations to 60 seconds or less.`);
  }
  await updateJob(options.jobId, { status: "processing", progress: 2, message: `Starting ${scenes.length} scene pipeline.` });
  const outputs: SceneOutput[] = [];
  for (let index = 0; index < scenes.length; index += 1) {
    outputs.push(await runSceneSteps(options.projectId, scenes[index], options.voice, {}));
    await updateJob(options.jobId, {
      progress: Math.round(((index + 1) / scenes.length) * 80),
      message: `Generated scene ${index + 1} of ${scenes.length}.`,
    });
  }
  await updateJob(options.jobId, { progress: 88, message: "Composing MP4 with FFmpeg." });
  const projectAssets = await db
    .select()
    .from(assetsTable)
    .where(eq(assetsTable.projectId, options.projectId))
    .orderBy(desc(assetsTable.createdAt));
  const uploadedMusic = projectAssets.find(
    (asset) => asset.source === "upload" && (asset.type === "music" || asset.type === "audio"),
  );
  const final = await composeEpisode(
    options.projectId,
    options.jobId,
    outputs,
    options.includeCaptions,
    options.includeMusic,
    options.includeMusic ? localMediaPath(uploadedMusic?.objectPath ?? null) : null,
  );
  const asset = await createAsset(options.projectId, "Final episode MP4", "video", "video/mp4", final.objectPath);
  await updateJob(options.jobId, { status: "complete", progress: 100, outputAssetId: asset.id, message: "Final MP4 ready." });
  await db
    .update(projectsTable)
    .set({ status: "exported", thumbnailUrl: outputs[0]?.captionPath ? mediaUrl(path.join(String(options.projectId), `scene-${scenes[0].id}.mp4`)) : null, updatedAt: new Date() })
    .where(eq(projectsTable.id, options.projectId));
}

export async function runRetryJob(jobId: number) {
  const [job] = await db.select().from(jobsTable).where(eq(jobsTable.id, jobId));
  if (!job) throw new Error("Job not found.");
  if (job.kind === "episode") {
    await runEpisodePipeline({
      projectId: job.projectId,
      jobId,
      voice: "en-us",
      includeCaptions: true,
      includeMusic: true,
    });
    return;
  }
  if (!job.sceneId || !["video", "voiceover", "captions"].includes(job.kind)) {
    throw new Error("Only scene and episode generation jobs can be retried.");
  }
  const [scene] = await db.select().from(scenesTable).where(eq(scenesTable.id, job.sceneId));
  if (!scene) throw new Error("Scene not found.");
  await updateJob(job.id, { status: "processing", progress: 5, message: "Retrying local provider." });
  await runSceneSteps(job.projectId, scene, "en-us", {
    videoJobId: job.kind === "video" ? job.id : undefined,
    voiceJobId: job.kind === "voiceover" ? job.id : undefined,
    captionJobId: job.kind === "captions" ? job.id : undefined,
  });
}
