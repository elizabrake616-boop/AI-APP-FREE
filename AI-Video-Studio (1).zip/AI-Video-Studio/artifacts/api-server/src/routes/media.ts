import express, { Router, type IRouter } from "express";
import path from "node:path";
import { mediaRoot } from "../providers/local-pipeline";

const router: IRouter = Router();
router.use("/media", express.static(mediaRoot, { maxAge: "1h", fallthrough: false }));
export default router;