import { Router, type IRouter } from "express";
import multer from "multer";
import path from "node:path";
import { mkdir } from "node:fs/promises";
import { and, asc, count, desc, eq, inArray } from "drizzle-orm";
import {
  AnalyzeProjectBody,
  AnalyzeProjectParams,
  AnalyzeProjectResponse,
  AddAssetBody,
  AddAssetParams,
  AddAssetResponse,
  CreateGenerationJobBody,
  CreateGenerationJobParams,
  CreateGenerationJobResponse,
  CreateProjectBody,
  CreateProjectResponse,
  DeleteProjectParams,
  ExportProjectBody,
  ExportProjectParams,
  ExportProjectResponse,
  GetProjectParams,
  GetProjectResponse,
  GetProjectsSummaryResponse,
  GenerateEpisodeBody,
  GenerateEpisodeParams,
  GenerateEpisodeResponse,
  ListJobsParams,
  ListJobsResponse,
  ListProjectsResponse,
  ListScenesParams,
  ListScenesResponse,
  UpdateProjectBody,
  UpdateProjectParams,
  UpdateProjectResponse,
  UpdateSceneBody,
  UpdateSceneParams,
  UpdateSceneResponse,
  RetryJobParams,
  RetryJobResponse,
  UploadAssetParams,
  UploadAssetResponse,
} from "@workspace/api-zod";
import { db } from "@workspace/db";
import {
  assetsTable,
  jobsTable,
  projectsTable,
  scenesTable,
} from "@workspace/db/schema";
import { getMediaProvider } from "../providers";
import {
  mediaRoot,
  runEpisodePipeline,
  runRetryJob,
} from "../providers/local-pipeline";

const router: IRouter = Router();

const iso = (value: Date) => value.toISOString();

function toProject(row: typeof projectsTable.$inferSelect, sceneCount = 0, totalDuration = 0) {
  return {
    id: row.id,
    title: row.title,
    story: row.story,
    status: row.status,
    sceneCount,
    totalDuration,
    updatedAt: iso(row.updatedAt),
    thumbnailUrl: row.thumbnailUrl,
  };
}

function toScene(row: typeof scenesTable.$inferSelect) {
  return {
    id: row.id,
    projectId: row.projectId,
    position: row.position,
    description: row.description,
    videoPrompt: row.videoPrompt,
    duration: row.duration,
    voiceover: row.voiceover,
    assetId: row.assetId,
    status: row.status,
    previewUrl: row.previewUrl,
  };
}

function toAsset(row: typeof assetsTable.$inferSelect) {
  return {
    id: row.id,
    projectId: row.projectId,
    name: row.name,
    type: row.type,
    mimeType: row.mimeType,
    objectPath: row.objectPath,
    source: row.source,
    createdAt: iso(row.createdAt),
  };
}

function toJob(row: typeof jobsTable.$inferSelect) {
  return {
    id: row.id,
    projectId: row.projectId,
    kind: row.kind,
    sceneId: row.sceneId,
    provider: row.provider,
    status: row.status,
    progress: row.progress,
    outputAssetId: row.outputAssetId,
    message: row.message,
    createdAt: iso(row.createdAt),
  };
}

const upload = multer({
  storage: multer.diskStorage({
    destination: (_req, _file, callback) => {
      const destination = path.join(mediaRoot, "uploads");
      void mkdir(destination, { recursive: true })
        .then(() => callback(null, destination))
        .catch((error: unknown) => callback(error as Error, destination));
    },
    filename: (_req, file, callback) => {
      const extension = path.extname(file.originalname).slice(0, 10);
      callback(null, `${Date.now()}-${Math.random().toString(36).slice(2, 9)}${extension}`);
    },
  }),
  limits: { fileSize: 200 * 1024 * 1024 },
});

async function projectDetail(projectId: number) {
  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, projectId));
  if (!project) return null;
  const scenes = await db
    .select()
    .from(scenesTable)
    .where(eq(scenesTable.projectId, projectId))
    .orderBy(asc(scenesTable.position));
  const assets = await db
    .select()
    .from(assetsTable)
    .where(eq(assetsTable.projectId, projectId))
    .orderBy(desc(assetsTable.createdAt));
  return {
    ...toProject(
      project,
      scenes.length,
      scenes.reduce((sum, scene) => sum + scene.duration, 0),
    ),
    scenes: scenes.map(toScene),
    assets: assets.map(toAsset),
  };
}

function splitIntoScenes(story: string, targetDuration: number) {
  const pieces = story
    .split(/(?<=[.!?])\s+|\n+/)
    .map((piece) => piece.trim())
    .filter(Boolean);
  const total = Math.max(1, Math.min(60, targetDuration));
  const source = (pieces.length ? pieces : [story.trim()]).slice(0, Math.min(12, Math.max(1, Math.floor(total))));
  const baseDuration = Math.floor((total / source.length) * 10) / 10;
  return source.map((piece, index) => ({
    position: index,
    description: piece,
    videoPrompt: `Vertical cinematic short-form video, scene ${index + 1}: ${piece}. Natural motion, expressive composition, strong subject, no text overlays.`,
    duration: index === source.length - 1
      ? Number((total - baseDuration * (source.length - 1)).toFixed(1))
      : Number(baseDuration.toFixed(1)),
    voiceover: piece,
    assetId: null,
  }));
}

router.get("/projects", async (_req, res, next) => {
  try {
    const projects = await db
      .select()
      .from(projectsTable)
      .orderBy(desc(projectsTable.updatedAt));
    const ids = projects.map((project) => project.id);
    const sceneRows = ids.length
      ? await db
          .select({
            projectId: scenesTable.projectId,
            sceneCount: count(scenesTable.id),
          })
          .from(scenesTable)
          .where(inArray(scenesTable.projectId, ids))
          .groupBy(scenesTable.projectId)
      : [];
    const sceneCountByProject = new Map(
      sceneRows.map((row) => [row.projectId, Number(row.sceneCount)]),
    );
    const scenes = ids.length
      ? await db
          .select({
            projectId: scenesTable.projectId,
            duration: scenesTable.duration,
          })
          .from(scenesTable)
          .where(inArray(scenesTable.projectId, ids))
      : [];
    const durationByProject = new Map<number, number>();
    for (const scene of scenes) {
      durationByProject.set(
        scene.projectId,
        (durationByProject.get(scene.projectId) ?? 0) + scene.duration,
      );
    }
    res.json(
      ListProjectsResponse.parse(
        projects.map((project) =>
          toProject(
            project,
            sceneCountByProject.get(project.id) ?? 0,
            durationByProject.get(project.id) ?? 0,
          ),
        ),
      ),
    );
  } catch (error) {
    next(error);
  }
});

router.post("/projects", async (req, res, next) => {
  try {
    const body = CreateProjectBody.parse(req.body);
    const [project] = await db
      .insert(projectsTable)
      .values({ title: body.title, story: body.story ?? "" })
      .returning();
    res.status(201).json(CreateProjectResponse.parse(toProject(project)));
  } catch (error) {
    next(error);
  }
});

router.get("/projects/summary", async (_req, res, next) => {
  try {
    const projects = await db.select().from(projectsTable).orderBy(desc(projectsTable.updatedAt));
    const scenes = await db.select().from(scenesTable);
    const sceneCountByProject = new Map<number, number>();
    const durationByProject = new Map<number, number>();
    for (const scene of scenes) {
      sceneCountByProject.set(
        scene.projectId,
        (sceneCountByProject.get(scene.projectId) ?? 0) + 1,
      );
      durationByProject.set(
        scene.projectId,
        (durationByProject.get(scene.projectId) ?? 0) + scene.duration,
      );
    }
    const summary = {
      projectCount: projects.length,
      readyCount: projects.filter((project) => project.status === "ready" || project.status === "exported").length,
      totalScenes: scenes.length,
      recent: projects.slice(0, 4).map((project) =>
        toProject(
          project,
          sceneCountByProject.get(project.id) ?? 0,
          durationByProject.get(project.id) ?? 0,
        ),
      ),
    };
    res.json(GetProjectsSummaryResponse.parse(summary));
  } catch (error) {
    next(error);
  }
});

router.get("/projects/:projectId", async (req, res, next) => {
  try {
    const { projectId } = GetProjectParams.parse({ projectId: Number(req.params.projectId) });
    const detail = await projectDetail(projectId);
    if (!detail) {
      res.status(404).json({ error: "Project not found" });
      return;
    }
    res.json(GetProjectResponse.parse(detail));
  } catch (error) {
    next(error);
  }
});

router.patch("/projects/:projectId", async (req, res, next) => {
  try {
    const params = UpdateProjectParams.parse({ projectId: Number(req.params.projectId) });
    const body = UpdateProjectBody.parse(req.body);
    const [project] = await db
      .update(projectsTable)
      .set({ ...body, updatedAt: new Date() })
      .where(eq(projectsTable.id, params.projectId))
      .returning();
    if (!project) {
      res.status(404).json({ error: "Project not found" });
      return;
    }
    const detail = await projectDetail(project.id);
    res.json(UpdateProjectResponse.parse(detail));
  } catch (error) {
    next(error);
  }
});

router.delete("/projects/:projectId", async (req, res, next) => {
  try {
    const { projectId } = DeleteProjectParams.parse({ projectId: Number(req.params.projectId) });
    const deleted = await db
      .delete(projectsTable)
      .where(eq(projectsTable.id, projectId))
      .returning({ id: projectsTable.id });
    if (!deleted.length) {
      res.status(404).json({ error: "Project not found" });
      return;
    }
    res.status(204).send();
  } catch (error) {
    next(error);
  }
});

router.post("/projects/:projectId/analyze", async (req, res, next) => {
  try {
    const params = AnalyzeProjectParams.parse({ projectId: Number(req.params.projectId) });
    const body = AnalyzeProjectBody.parse(req.body);
    const scenes = splitIntoScenes(body.story, body.targetDuration ?? 45);
    const detail = await db.transaction(async (tx) => {
      const [project] = await tx
        .update(projectsTable)
        .set({ story: body.story, status: "ready", updatedAt: new Date() })
        .where(eq(projectsTable.id, params.projectId))
        .returning();
      if (!project) return null;
      await tx.delete(scenesTable).where(eq(scenesTable.projectId, params.projectId));
      await tx.insert(scenesTable).values(
        scenes.map((scene) => ({ projectId: params.projectId, ...scene })),
      );
      return project;
    });
    if (!detail) {
      res.status(404).json({ error: "Project not found" });
      return;
    }
    const result = await projectDetail(detail.id);
    res.json(AnalyzeProjectResponse.parse(result));
  } catch (error) {
    next(error);
  }
});

router.get("/projects/:projectId/scenes", async (req, res, next) => {
  try {
    const { projectId } = ListScenesParams.parse({ projectId: Number(req.params.projectId) });
    const scenes = await db
      .select()
      .from(scenesTable)
      .where(eq(scenesTable.projectId, projectId))
      .orderBy(asc(scenesTable.position));
    res.json(ListScenesResponse.parse(scenes.map(toScene)));
  } catch (error) {
    next(error);
  }
});

router.patch("/projects/:projectId/scenes/:sceneId", async (req, res, next) => {
  try {
    const params = UpdateSceneParams.parse({
      projectId: Number(req.params.projectId),
      sceneId: Number(req.params.sceneId),
    });
    const body = UpdateSceneBody.parse(req.body);
    const [scene] = await db
      .update(scenesTable)
      .set(body)
      .where(
        and(eq(scenesTable.id, params.sceneId), eq(scenesTable.projectId, params.projectId)),
      )
      .returning();
    if (!scene) {
      res.status(404).json({ error: "Scene not found" });
      return;
    }
    await db.update(projectsTable).set({ updatedAt: new Date() }).where(eq(projectsTable.id, params.projectId));
    res.json(UpdateSceneResponse.parse(toScene(scene)));
  } catch (error) {
    next(error);
  }
});

router.post("/projects/:projectId/assets", async (req, res, next) => {
  try {
    const params = AddAssetParams.parse({ projectId: Number(req.params.projectId) });
    const body = AddAssetBody.parse(req.body);
    const [asset] = await db
      .insert(assetsTable)
      .values({ projectId: params.projectId, ...body })
      .returning();
    res.status(201).json(AddAssetResponse.parse(toAsset(asset)));
  } catch (error) {
    next(error);
  }
});

router.post(
  "/projects/:projectId/assets/upload",
  upload.single("file"),
  async (req, res, next) => {
    try {
      const params = UploadAssetParams.parse({ projectId: Number(req.params.projectId) });
      const file = req.file;
      if (!file) {
        res.status(400).json({ error: "Choose a file to upload." });
        return;
      }
      const type = file.mimetype.startsWith("video")
        ? "video"
        : file.mimetype.startsWith("audio")
          ? "audio"
          : file.mimetype.startsWith("image")
            ? "image"
            : null;
      if (!type) {
        res.status(415).json({ error: "Unsupported asset type. Upload an image, video, or audio file." });
        return;
      }
      const objectPath = `/api/media/uploads/${path.basename(file.path)}`;
      const [asset] = await db
        .insert(assetsTable)
        .values({
          projectId: params.projectId,
          name: file.originalname,
          type,
          mimeType: file.mimetype || "application/octet-stream",
          objectPath,
          source: "upload",
        })
        .returning();
      res.status(201).json(UploadAssetResponse.parse(toAsset(asset)));
    } catch (error) {
      next(error);
    }
  },
);

router.get("/projects/:projectId/jobs", async (req, res, next) => {
  try {
    const { projectId } = ListJobsParams.parse({ projectId: Number(req.params.projectId) });
    const jobs = await db
      .select()
      .from(jobsTable)
      .where(eq(jobsTable.projectId, projectId))
      .orderBy(desc(jobsTable.createdAt));
    res.json(ListJobsResponse.parse(jobs.map(toJob)));
  } catch (error) {
    next(error);
  }
});

router.post("/projects/:projectId/jobs", async (req, res, next) => {
  try {
    const params = CreateGenerationJobParams.parse({ projectId: Number(req.params.projectId) });
    const body = CreateGenerationJobBody.parse(req.body);
    const provider = getMediaProvider(body.kind, body.provider);
    const [job] = await db
      .insert(jobsTable)
      .values({
        projectId: params.projectId,
        kind: body.kind,
        provider: provider.name,
        message: `Queued for ${provider.name}. Provider adapter is ready to connect.`,
      })
      .returning();
    res.status(202).json(CreateGenerationJobResponse.parse(toJob(job)));
    if (job.sceneId && ["video", "voiceover", "captions"].includes(job.kind)) {
      void runRetryJob(job.id).catch(async (error: unknown) => {
        await db
          .update(jobsTable)
          .set({ status: "failed", message: error instanceof Error ? error.message : "Provider failed." })
          .where(eq(jobsTable.id, job.id));
      });
    }
  } catch (error) {
    next(error);
  }
});

router.post("/projects/:projectId/generate-episode", async (req, res, next) => {
  try {
    const params = GenerateEpisodeParams.parse({ projectId: Number(req.params.projectId) });
    const body = GenerateEpisodeBody.parse(req.body);
    const [job] = await db
      .insert(jobsTable)
      .values({
        projectId: params.projectId,
        kind: "episode",
        provider: "local-ffmpeg-pipeline",
        message: "Queued: scenes → video → voice-over → captions → MP4.",
      })
      .returning();
    await db
      .update(projectsTable)
      .set({ status: "rendering", updatedAt: new Date() })
      .where(eq(projectsTable.id, params.projectId));
    res.status(202).json(GenerateEpisodeResponse.parse(toJob(job)));
    void runEpisodePipeline({
      projectId: params.projectId,
      jobId: job.id,
      voice: body.voice,
      includeCaptions: body.includeCaptions ?? true,
      includeMusic: body.includeMusic ?? false,
    }).catch(async (error: unknown) => {
      await db
        .update(jobsTable)
        .set({
          status: "failed",
          message: error instanceof Error ? error.message : "Episode generation failed.",
        })
        .where(eq(jobsTable.id, job.id));
      await db
        .update(projectsTable)
        .set({ status: "ready", updatedAt: new Date() })
        .where(eq(projectsTable.id, params.projectId));
    });
  } catch (error) {
    next(error);
  }
});

router.post("/projects/:projectId/export", async (req, res, next) => {
  try {
    const params = ExportProjectParams.parse({ projectId: Number(req.params.projectId) });
    const body = ExportProjectBody.parse(req.body);
    const provider = getMediaProvider("export");
    const [job] = await db
      .insert(jobsTable)
      .values({
        projectId: params.projectId,
        kind: "export",
        provider: provider.name,
        message: `Queued vertical ${body.width}x${body.height} MP4 export. FFmpeg adapter is ready to connect.`,
      })
      .returning();
    await db
      .update(projectsTable)
      .set({ status: "rendering", updatedAt: new Date() })
      .where(eq(projectsTable.id, params.projectId));
    res.status(202).json(ExportProjectResponse.parse(toJob(job)));
  } catch (error) {
    next(error);
  }
});

router.post("/jobs/:jobId/retry", async (req, res, next) => {
  try {
    const { jobId } = RetryJobParams.parse({ jobId: Number(req.params.jobId) });
    const [job] = await db
      .update(jobsTable)
      .set({ status: "queued", progress: 0, message: "Retry queued." })
      .where(eq(jobsTable.id, jobId))
      .returning();
    if (!job) {
      res.status(404).json({ error: "Job not found." });
      return;
    }
    res.status(202).json(RetryJobResponse.parse(toJob(job)));
    void runRetryJob(job.id).catch(async (error: unknown) => {
      await db
        .update(jobsTable)
        .set({ status: "failed", message: error instanceof Error ? error.message : "Retry failed." })
        .where(eq(jobsTable.id, job.id));
    });
  } catch (error) {
    next(error);
  }
});

export default router;