import { Film, FolderKanban, Home, Plus, Sparkles, Video } from 'lucide-react';
import type { ReactNode } from 'react';
import { Link, useLocation } from 'wouter';

export function StudioShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const nav = [
    { href: '/', label: 'Studio', icon: Home },
    { href: '/projects', label: 'Projects', icon: FolderKanban },
  ];
  return (
    <div className="grain min-h-[100dvh] bg-background text-foreground">
      <aside className="fixed inset-y-0 left-0 z-20 hidden w-[238px] flex-col border-r border-sidebar-border bg-sidebar px-5 py-6 text-sidebar-foreground lg:flex">
        <Link href="/" className="mb-12 flex items-center gap-3" data-testid="link-studio-logo">
          <span className="grid size-9 place-items-center rounded-xl bg-sidebar-primary text-sidebar-primary-foreground"><Video size={18} strokeWidth={2.5} /></span>
          <span><span className="block font-display text-lg font-bold tracking-tight">framewise</span><span className="font-mono-ui text-[9px] uppercase tracking-[.2em] text-sidebar-foreground/45">personal studio</span></span>
        </Link>
        <p className="mb-3 px-2 font-mono-ui text-[10px] uppercase tracking-[.18em] text-sidebar-foreground/40">Workspace</p>
        <nav className="space-y-1">
          {nav.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-nav-${label.toLowerCase()}`} className={`flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-semibold transition-colors ${location === href ? 'bg-sidebar-accent text-sidebar-accent-foreground' : 'text-sidebar-foreground/60 hover:bg-sidebar-accent/70 hover:text-sidebar-foreground'}`}><Icon size={17} />{label}</Link>)}
        </nav>
        <Link href="/projects/new" data-testid="link-new-project" className="mt-8 flex items-center justify-between rounded-xl bg-sidebar-primary px-3 py-3 text-sm font-bold text-sidebar-primary-foreground transition-transform hover:-translate-y-0.5">
          <span className="flex items-center gap-2"><Plus size={16} />New story</span><span className="font-mono-ui text-[10px] opacity-60">N</span>
        </Link>
        <div className="mt-auto rounded-2xl border border-sidebar-border bg-sidebar-accent/40 p-4">
          <div className="mb-3 flex items-center gap-2 text-sidebar-primary"><Sparkles size={15} /><span className="font-mono-ui text-[10px] uppercase tracking-widest">Creator note</span></div>
          <p className="text-xs leading-relaxed text-sidebar-foreground/60">Keep the first idea. Polish comes after the cut.</p>
        </div>
      </aside>
      <main className="min-h-[100dvh] lg:pl-[238px]">
        <header className="flex items-center justify-between border-b border-border/70 px-5 py-4 lg:hidden">
          <Link href="/" className="flex items-center gap-2 font-display font-bold" data-testid="link-mobile-logo"><span className="grid size-8 place-items-center rounded-lg bg-primary text-primary-foreground"><Video size={15} /></span>framewise</Link>
          <Link href="/projects/new" className="grid size-9 place-items-center rounded-lg bg-accent text-accent-foreground" data-testid="link-mobile-new"><Plus size={18} /></Link>
        </header>
        {children}
      </main>
    </div>
  );
}