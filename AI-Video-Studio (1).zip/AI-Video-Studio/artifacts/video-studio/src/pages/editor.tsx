import {
  AlertTriangle,
  ArrowLeft,
  Check,
  CheckCircle2,
  Clapperboard,
  Download,
  FileAudio,
  FileImage,
  FileVideo,
  Layers3,
  Loader2,
  Play,
  RefreshCw,
  Save,
  Upload,
  WandSparkles,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useParams } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  getGetProjectQueryKey,
  getListJobsQueryKey,
  getListScenesQueryKey,
  useAnalyzeProject,
  useGenerateEpisode,
  useGetProject,
  useListJobs,
  useListScenes,
  useRetryJob,
  useUpdateProject,
  useUpdateScene,
  useUploadAsset,
} from "@workspace/api-client-react";
import { LoadingBlock, SectionHeading, StatusPill } from "@/components/studio-ui";

type Scene = {
  id: number;
  projectId: number;
  position: number;
  description: string;
  videoPrompt: string;
  duration: number;
  voiceover: string;
  assetId: number | null;
  status: string;
  previewUrl: string | null;
};

type Job = {
  id: number;
  projectId: number;
  kind: string;
  sceneId: number | null;
  provider: string;
  status: string;
  progress: number;
  outputAssetId: number | null;
  message: string;
  createdAt: string;
};

function SceneEditor({
  projectId,
  scene,
  selected,
  onSelect,
  jobs,
  duration,
  onDurationChange,
  onDurationCommit,
}: {
  projectId: number;
  scene: Scene;
  selected: boolean;
  onSelect: () => void;
  jobs: Job[];
  duration: number;
  onDurationChange: (value: number) => void;
  onDurationCommit: (value: number) => void;
}) {
  const update = useUpdateScene();
  const queryClient = useQueryClient();
  const sceneJobs = jobs.filter((job) => job.sceneId === scene.id);
  const sceneProgress = sceneJobs.length
    ? Math.round(sceneJobs.reduce((sum, job) => sum + job.progress, 0) / sceneJobs.length)
    : null;
  const save = (field: string, value: string | number) =>
    update.mutate(
      { projectId, sceneId: scene.id, data: { [field]: value } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListScenesQueryKey(projectId) });
          queryClient.invalidateQueries({ queryKey: getGetProjectQueryKey(projectId) });
        },
      },
    );

  return (
    <div
      className={`rounded-2xl border ${selected ? "border-primary bg-primary/[.03]" : "border-border bg-card"} p-4 transition-colors`}
      data-testid={`scene-card-${scene.id}`}
    >
      <button
        onClick={onSelect}
        className="flex w-full items-start gap-3 text-left"
        data-testid={`button-select-scene-${scene.id}`}
      >
        <span
          className={`grid size-7 shrink-0 place-items-center rounded-lg font-mono-ui text-[11px] ${selected ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
        >
          {String(scene.position + 1).padStart(2, "0")}
        </span>
        <span className="min-w-0 flex-1">
          <span className="flex items-center justify-between gap-2">
            <span className="truncate text-sm font-bold">{scene.description || "Untitled scene"}</span>
            <StatusPill status={scene.status} />
          </span>
          <span className="mt-1 block font-mono-ui text-[10px] uppercase tracking-wider text-muted-foreground">
            {scene.duration}s / vertical 9:16
          </span>
          {sceneProgress !== null && (
            <span className="mt-2 block h-1 overflow-hidden rounded-full bg-muted">
              <span className="block h-full rounded-full bg-primary transition-all" style={{ width: `${sceneProgress}%` }} />
            </span>
          )}
        </span>
      </button>
      {selected && (
        <div className="mt-4 space-y-3 border-t border-border pt-4">
          <label className="block text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            Scene direction
            <textarea
              defaultValue={scene.description}
              onBlur={(event) => save("description", event.target.value)}
              rows={2}
              className="mt-1 w-full resize-none rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              data-testid={`input-scene-description-${scene.id}`}
            />
          </label>
          <label className="block text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
            Video prompt
            <textarea
              defaultValue={scene.videoPrompt}
              onBlur={(event) => save("videoPrompt", event.target.value)}
              rows={3}
              className="mt-1 w-full resize-none rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              data-testid={`input-scene-prompt-${scene.id}`}
            />
          </label>
          <div className="grid grid-cols-[100px_1fr] gap-2">
            <label className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
              Seconds
              <input
                type="number"
                min={1}
                max={60}
                value={duration}
                onChange={(event) => onDurationChange(Math.max(1, Math.min(60, Number(event.target.value) || 1)))}
                onBlur={() => onDurationCommit(duration)}
                className="mt-1 w-full rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none"
                data-testid={`input-scene-duration-${scene.id}`}
              />
            </label>
            <label className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
              Voice-over
              <textarea
                defaultValue={scene.voiceover}
                onBlur={(event) => save("voiceover", event.target.value)}
                rows={1}
                className="mt-1 w-full resize-none rounded-lg border border-input bg-background px-3 py-2 text-sm outline-none"
                data-testid={`input-scene-voiceover-${scene.id}`}
              />
            </label>
          </div>
        </div>
      )}
    </div>
  );
}

function JobRow({ job, onRetry }: { job: Job; onRetry: () => void }) {
  const icon =
    job.status === "complete" ? (
      <CheckCircle2 size={14} className="text-emerald-600" />
    ) : job.status === "failed" ? (
      <AlertTriangle size={14} className="text-destructive" />
    ) : (
      <Loader2 size={14} className="animate-spin text-primary" />
    );
  return (
    <div className="rounded-xl border border-border bg-background p-3" data-testid={`job-row-${job.id}`}>
      <div className="flex items-center gap-2">
        {icon}
        <span className="min-w-0 flex-1 truncate text-xs font-bold">
          {job.sceneId ? `Scene ${job.sceneId} · ${job.kind}` : job.kind === "episode" ? "Final episode" : job.kind}
        </span>
        <span className="font-mono-ui text-[10px] text-muted-foreground">{job.progress}%</span>
      </div>
      <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
        <div
          className={`h-full rounded-full transition-all ${job.status === "failed" ? "bg-destructive" : "bg-primary"}`}
          style={{ width: `${job.progress}%` }}
        />
      </div>
      <div className="mt-2 flex items-center justify-between gap-2">
        <p className={`text-[10px] leading-relaxed ${job.status === "failed" ? "text-destructive" : "text-muted-foreground"}`}>
          {job.message}
        </p>
        {job.status === "failed" && (
          <button
            onClick={onRetry}
            className="flex shrink-0 items-center gap-1 rounded-lg border border-border px-2 py-1 text-[10px] font-bold hover:border-primary"
            data-testid={`button-retry-job-${job.id}`}
          >
            <RefreshCw size={11} /> Retry
          </button>
        )}
      </div>
    </div>
  );
}

export function Editor() {
  const params = useParams<{ id: string }>();
  const projectId = Number(params.id);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const projectQuery = useGetProject(projectId, { query: { queryKey: getGetProjectQueryKey(projectId) } });
  const scenesQuery = useListScenes(projectId, { query: { queryKey: getListScenesQueryKey(projectId) } });
  const jobsQuery = useListJobs(projectId, { query: { queryKey: getListJobsQueryKey(projectId), refetchInterval: 1000 } });
  const updateProject = useUpdateProject();
  const updateScene = useUpdateScene();
  const analyze = useAnalyzeProject();
  const generateEpisode = useGenerateEpisode();
  const retryJob = useRetryJob();
  const uploadAsset = useUploadAsset();
  const [selected, setSelected] = useState<number | null>(null);
  const [story, setStory] = useState("");
  const [targetDuration, setTargetDuration] = useState(30);
  const [durationDrafts, setDurationDrafts] = useState<Record<number, number>>({});
  const [voice, setVoice] = useState("en-us");
  const [includeCaptions, setIncludeCaptions] = useState(true);
  const [includeMusic, setIncludeMusic] = useState(false);
  const [showExport, setShowExport] = useState(false);
  const [localPreview, setLocalPreview] = useState<string | null>(null);
  const [localPreviewType, setLocalPreviewType] = useState<"image" | "video" | "audio" | null>(null);
  const [notice, setNotice] = useState("");
  const fileInput = useRef<HTMLInputElement>(null);
  const project = projectQuery.data;
  const scenes = (scenesQuery.data ?? project?.scenes ?? []) as Scene[];
  const assets = project?.assets ?? [];
  const jobs = (jobsQuery.data ?? []) as Job[];
  const effectiveScenes = scenes.map((scene) => ({
    ...scene,
    duration: durationDrafts[scene.id] ?? scene.duration,
  }));
  const totalDuration = effectiveScenes.reduce((sum, scene) => sum + scene.duration, 0);
  const isBusy = jobs.some((job) => job.status === "queued" || job.status === "processing");
  const latestEpisode = jobs.find((job) => job.kind === "episode");
  const finalAsset = assets.find((asset) => asset.id === latestEpisode?.outputAssetId) ??
    assets.find((asset) => asset.name === "Final episode MP4");

  useEffect(() => {
    if (project && !story) setStory(project.story);
  }, [project, story]);
  useEffect(() => {
    if (selected === null && scenes[0]) setSelected(scenes[0].id);
  }, [scenes, selected]);

  const activeScene = useMemo(
    () => effectiveScenes.find((scene) => scene.id === selected) ?? effectiveScenes[0],
    [effectiveScenes, selected],
  );
  const activeAsset = assets.find((asset) => asset.id === activeScene?.assetId);

  if (projectQuery.isLoading) {
    return <div className="mx-auto max-w-7xl p-6 lg:p-12"><LoadingBlock label="Opening the edit desk" /></div>;
  }
  if (projectQuery.isError) {
    return (
      <div className="mx-auto max-w-2xl p-6 text-center lg:p-12">
        <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-10">
          <h2 className="font-display text-2xl font-bold">This desk is out of reach.</h2>
          <p className="mt-2 text-sm text-muted-foreground">We could not open the project. Give it another try.</p>
          <button onClick={() => projectQuery.refetch()} className="mt-5 rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground" data-testid="button-retry-project">Try again</button>
        </div>
      </div>
    );
  }
  if (!project) {
    return (
      <div className="mx-auto max-w-3xl p-12 text-center">
        <AlertTriangle className="mx-auto text-destructive" />
        <h1 className="mt-4 font-display text-2xl font-bold">That story is not here.</h1>
        <button onClick={() => setLocation("/projects")} className="mt-5 text-sm font-bold text-primary" data-testid="button-back-projects">Back to projects</button>
      </div>
    );
  }

  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: getGetProjectQueryKey(projectId) });
    queryClient.invalidateQueries({ queryKey: getListScenesQueryKey(projectId) });
    queryClient.invalidateQueries({ queryKey: getListJobsQueryKey(projectId) });
  };
  const saveStory = () => {
    if (story.trim() !== project.story) {
      updateProject.mutate(
        { projectId, data: { story: story.trim() } },
        { onSuccess: () => { refresh(); setNotice("Saved just now"); } },
      );
    }
  };
  const startEpisode = () => {
    if (totalDuration < 1 || totalDuration > 60) {
      setNotice(`Episode total must be between 1 and 60 seconds. Current total: ${totalDuration.toFixed(1)}s.`);
      return;
    }
    generateEpisode.mutate(
      { projectId, data: { voice, includeCaptions, includeMusic } },
      { onSuccess: () => { refresh(); setNotice("Episode generation started"); } },
    );
  };
  const generate = () => {
    if (!story.trim() || isBusy) return;
    const needsAnalysis = scenes.length === 0 || story.trim() !== project.story.trim();
    if (needsAnalysis) {
      analyze.mutate(
        { projectId, data: { story: story.trim(), targetDuration } },
        { onSuccess: () => { refresh(); startEpisode(); } },
      );
    } else {
      startEpisode();
    }
  };
  const handleFile = (file?: File) => {
    if (!file) return;
    const extensionAllowed = /\.(jpe?g|png|webp|mp4|mov|webm|mp3|wav|m4a)$/i.test(file.name);
    const type = file.type.startsWith("image")
      ? "image"
      : file.type.startsWith("video")
        ? "video"
        : file.type.startsWith("audio")
          ? "audio"
          : null;
    if (!type || !extensionAllowed) {
      setNotice("Unsupported file. Use JPG, JPEG, PNG, WEBP, MP4, MOV, WEBM, MP3, WAV, or M4A.");
      return;
    }
    setLocalPreview(URL.createObjectURL(file));
    setLocalPreviewType(type);
    uploadAsset.mutate(
      { projectId, data: { file } },
      { onSuccess: (asset) => { refresh(); setNotice("Imported asset and stored it locally"); } },
    );
  };
  const updateDurationDraft = (sceneId: number, value: number) => {
    const nextTotal = effectiveScenes.reduce(
      (sum, scene) => sum + (scene.id === sceneId ? value : scene.duration),
      0,
    );
    if (nextTotal > 60) {
      setNotice(`Episode total cannot exceed 60 seconds. Current total: ${nextTotal.toFixed(1)}s.`);
      return;
    }
    setDurationDrafts((current) => ({ ...current, [sceneId]: value }));
    setNotice("");
  };
  const commitDuration = (sceneId: number, value: number) => {
    updateScene.mutate(
      { projectId, sceneId, data: { duration: value } },
      { onSuccess: () => { refresh(); setNotice("Scene duration saved"); } },
    );
  };
  const assignAsset = (assetId: number) => {
    if (!activeScene) return;
    updateScene.mutate(
      { projectId, sceneId: activeScene.id, data: { assetId } },
      { onSuccess: () => { refresh(); setNotice(`Asset assigned to scene ${activeScene.position + 1}`); } },
    );
  };
  const retry = (job: Job) => retryJob.mutate({ jobId: job.id }, { onSuccess: refresh });

  return (
    <div className="mx-auto max-w-[1500px] px-5 py-5 lg:px-8 lg:py-7">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button onClick={() => setLocation("/projects")} className="grid size-9 place-items-center rounded-xl border border-border bg-card text-muted-foreground hover:text-foreground" data-testid="button-back-projects"><ArrowLeft size={16} /></button>
          <div>
            <div className="flex items-center gap-2"><p className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-muted-foreground">Editing story</p><StatusPill status={project.status} /></div>
            <h1 className="font-display text-2xl font-bold tracking-tight">{project.title}</h1>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {notice && <span className="mr-2 flex items-center gap-1.5 font-mono-ui text-[10px] text-primary"><Check size={13} />{notice}</span>}
          <button onClick={saveStory} className="flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2 text-xs font-bold hover:border-primary" data-testid="button-save-story"><Save size={14} />Save</button>
          <button onClick={() => setShowExport(true)} disabled={isBusy || !story.trim()} className="flex items-center gap-2 rounded-xl bg-primary px-3 py-2 text-xs font-bold text-primary-foreground disabled:opacity-50" data-testid="button-open-export"><Clapperboard size={14} />Generate Episode</button>
        </div>
      </div>

      <div className="mt-7 grid gap-5 xl:grid-cols-[320px_minmax(350px,1fr)_310px]">
        <section className="space-y-5">
          <div className="rounded-2xl border border-border bg-card p-5">
            <SectionHeading eyebrow="01 / source" title="The rough cut" />
            <textarea value={story} onChange={(event) => setStory(event.target.value)} rows={8} className="w-full resize-none rounded-xl border border-input bg-background p-3 text-sm leading-relaxed outline-none focus:border-primary" placeholder="Put the messy version here." data-testid="textarea-project-story" />
            <button onClick={() => analyze.mutate({ projectId, data: { story: story.trim(), targetDuration: 30 } }, { onSuccess: refresh })} disabled={analyze.isPending || !story.trim()} className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-accent px-3 py-3 text-xs font-bold text-accent-foreground disabled:opacity-50" data-testid="button-analyze-story"><WandSparkles size={15} />{analyze.isPending ? "Finding the cut..." : "Analyze into scenes"}</button>
            <p className="mt-3 text-[11px] leading-relaxed text-muted-foreground">Analysis creates a maximum 30-second sequence. You can edit every scene before generating.</p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-5">
            <SectionHeading eyebrow="02 / scenes" title={`${scenes.length} beats`} />
            {scenes.length ? <div className="space-y-2">{scenes.map((scene) => <SceneEditor key={scene.id} projectId={projectId} scene={scene} jobs={jobs} selected={activeScene?.id === scene.id} onSelect={() => setSelected(scene.id)} />)}</div> : <div className="rounded-xl bg-muted p-4 text-sm text-muted-foreground">Analyze your story to build the first sequence.</div>}
          </div>
        </section>

        <section className="space-y-5">
          <div className="rounded-2xl border border-border bg-[#1d2930] p-4 text-[#f7f2e8]">
            <div className="mb-4 flex items-center justify-between">
              <div><p className="font-mono-ui text-[10px] uppercase tracking-widest text-[#d9b85a]">Scene preview</p><p className="mt-1 text-xs text-white/45">{activeScene ? `Beat ${String(activeScene.position + 1).padStart(2, "0")} / ${activeScene.duration}s` : "No scene selected"}</p></div>
              <button className="grid size-9 place-items-center rounded-full bg-[#d9b85a] text-[#1d2930]" data-testid="button-play-preview"><Play size={15} fill="currentColor" /></button>
            </div>
            <div className="relative mx-auto aspect-[9/16] max-h-[62vh] overflow-hidden rounded-xl bg-[#30484c] shadow-2xl shadow-black/30">
              {activeScene?.previewUrl || localPreview ? <video src={activeScene?.previewUrl ?? localPreview ?? undefined} controls className="size-full object-cover" /> : <div className="bg-grid relative flex size-full items-center justify-center"><div className="absolute inset-x-0 bottom-0 h-2/5 bg-gradient-to-t from-[#162228] to-transparent" /><div className="relative max-w-[75%] text-center"><span className="font-mono-ui text-[10px] uppercase tracking-[.2em] text-[#d9b85a]">framewise / preview</span><p className="mt-4 font-display text-2xl font-bold leading-tight text-white/90">{activeScene?.description || "Your first frame is waiting."}</p></div></div>}
              <div className="absolute bottom-3 left-3 rounded-md bg-black/30 px-2 py-1 font-mono-ui text-[9px] text-white/60">9:16 • 720 × 1280</div>
            </div>
          </div>
          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-widest text-primary">Generation desk</p><h3 className="mt-1 font-display text-lg font-bold">Local episode pipeline</h3></div><Clapperboard size={17} className="text-muted-foreground" /></div>
            <p className="mt-2 text-xs leading-relaxed text-muted-foreground">Runs scene clips, espeak-ng voice-over, timed SRT captions, optional music, and FFmpeg composition locally. The scene visual provider is intentionally a non-AI motion fallback until a local video model is installed.</p>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <label className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">Voice<select value={voice} onChange={(event) => setVoice(event.target.value)} className="mt-1 w-full rounded-xl border border-input bg-background px-3 py-2.5 text-sm font-normal text-foreground" data-testid="select-voice"><option value="en-us">English · neutral</option><option value="en+f2">English · warm</option><option value="en+f3">English · bright</option><option value="en+f5">English · low</option></select></label>
              <div className="space-y-2 pt-5"><label className="flex items-center gap-2 text-xs font-semibold"><input type="checkbox" checked={includeCaptions} onChange={(event) => setIncludeCaptions(event.target.checked)} data-testid="checkbox-episode-captions" />Burn captions into MP4</label><label className="flex items-center gap-2 text-xs font-semibold"><input type="checkbox" checked={includeMusic} onChange={(event) => setIncludeMusic(event.target.checked)} data-testid="checkbox-episode-music" />Add local music bed</label></div>
            </div>
            <button onClick={generate} disabled={isBusy || !story.trim() || generateEpisode.isPending || analyze.isPending} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground disabled:opacity-50" data-testid="button-generate-episode"><Clapperboard size={16} />{isBusy || generateEpisode.isPending || analyze.isPending ? "Generating episode..." : "Generate Episode"}</button>
          </div>
          {jobs.length > 0 && <div className="rounded-2xl border border-border bg-card p-5"><div className="flex items-center justify-between"><SectionHeading eyebrow="05 / progress" title="Render status" />{isBusy && <Loader2 size={15} className="animate-spin text-primary" />}</div><div className="mt-4 space-y-2">{jobs.slice(0, 14).map((job) => <JobRow key={job.id} job={job} onRetry={() => retry(job)} />)}</div></div>}
        </section>

        <section className="space-y-5">
          <div className="rounded-2xl border border-border bg-card p-5">
            <div className="flex items-center justify-between"><SectionHeading eyebrow="03 / assets" title="The shelf" /><button onClick={() => fileInput.current?.click()} className="grid size-8 place-items-center rounded-lg bg-accent text-accent-foreground" data-testid="button-import-asset"><Upload size={15} /></button><input ref={fileInput} type="file" accept="image/*,video/*,audio/*" className="hidden" onChange={(event) => handleFile(event.target.files?.[0])} data-testid="input-asset-file" /></div>
            {assets.length || localPreview ? <div className="space-y-2">{localPreview && <div className="flex items-center gap-3 rounded-xl bg-muted p-2"><div className="grid size-9 place-items-center rounded-lg bg-primary/10 text-primary"><FileVideo size={16} /></div><span className="min-w-0 flex-1 truncate text-xs font-semibold">Selected upload</span><span className="font-mono-ui text-[9px] uppercase text-primary">{uploadAsset.isPending ? "uploading" : "ready"}</span></div>}{assets.map((asset) => <div key={asset.id} className="flex items-center gap-3 rounded-xl bg-muted p-2" data-testid={`asset-row-${asset.id}`}><div className="grid size-9 place-items-center rounded-lg bg-primary/10 text-primary">{asset.type === "image" ? <FileImage size={16} /> : asset.type === "audio" || asset.type === "music" ? <FileAudio size={16} /> : <FileVideo size={16} />}</div><span className="min-w-0 flex-1 truncate text-xs font-semibold">{asset.name}</span><span className="font-mono-ui text-[9px] uppercase text-muted-foreground">{asset.source}</span></div>)}</div> : <button onClick={() => fileInput.current?.click()} className="w-full rounded-xl border border-dashed border-border p-6 text-center text-xs text-muted-foreground hover:border-primary" data-testid="button-empty-assets"><Upload size={17} className="mx-auto mb-2 text-primary" />Drop a frame, clip, or track here</button>}
            <p className="mt-4 text-[10px] leading-relaxed text-muted-foreground">Images, videos, and audio are uploaded to the local generated-media directory and remain available to the compositor.</p>
          </div>
          <div className="rounded-2xl border border-border bg-card p-5">
            <SectionHeading eyebrow="04 / final frame" title="Export preview" />
            {finalAsset?.objectPath ? <div className="overflow-hidden rounded-xl bg-[#30484c]"><video src={finalAsset.objectPath} controls className="aspect-[9/16] max-h-72 w-full object-cover" /><a href={finalAsset.objectPath} download className="flex items-center justify-center gap-2 border-t border-white/10 bg-card py-3 text-xs font-bold text-primary"><Download size={14} />Download final MP4</a></div> : <div className="flex items-center gap-4 rounded-xl bg-muted p-3"><div className="relative grid h-24 w-14 place-items-center overflow-hidden rounded-lg bg-[#30484c]"><span className="font-mono-ui text-[8px] text-accent">9:16</span><div className="absolute bottom-0 h-1/3 w-full bg-primary/30" /></div><div><p className="text-sm font-bold">Vertical short</p><p className="mt-1 font-mono-ui text-[10px] uppercase tracking-wider text-muted-foreground">720 × 1280 · MP4</p><p className="mt-2 text-[11px] text-muted-foreground">Maximum 30 seconds</p></div></div>}
            <button onClick={() => setShowExport(true)} disabled={isBusy || !story.trim()} className="mt-4 flex w-full items-center justify-center gap-2 rounded-xl border border-primary py-2.5 text-xs font-bold text-primary hover:bg-primary hover:text-primary-foreground disabled:opacity-50" data-testid="button-export-preview"><Download size={14} />Prepare final MP4</button>
          </div>
        </section>
      </div>
      {showExport && <ExportDialog projectId={projectId} voice={voice} includeCaptions={includeCaptions} includeMusic={includeMusic} setVoice={setVoice} setIncludeCaptions={setIncludeCaptions} setIncludeMusic={setIncludeMusic} onClose={() => setShowExport(false)} onGenerate={() => { setShowExport(false); generate(); }} />}
    </div>
  );
}

function ExportDialog({
  projectId,
  voice,
  includeCaptions,
  includeMusic,
  setVoice,
  setIncludeCaptions,
  setIncludeMusic,
  onClose,
  onGenerate,
}: {
  projectId: number;
  voice: string;
  includeCaptions: boolean;
  includeMusic: boolean;
  setVoice: (value: string) => void;
  setIncludeCaptions: (value: boolean) => void;
  setIncludeMusic: (value: boolean) => void;
  onClose: () => void;
  onGenerate: () => void;
}) {
  void projectId;
  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-foreground/30 p-5 backdrop-blur-sm" data-testid="dialog-export">
      <div className="w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-2xl">
        <div className="flex items-start justify-between"><div><p className="font-mono-ui text-[10px] uppercase tracking-widest text-primary">Final export</p><h2 className="mt-2 font-display text-2xl font-bold">Set the frame.</h2></div><button onClick={onClose} className="text-muted-foreground" data-testid="button-close-export"><X size={18} /></button></div>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">The local renderer is locked to vertical 9:16 at 720 × 1280, MP4, and a maximum 30-second episode.</p>
        <label className="mt-5 block text-xs font-bold">Voice<select value={voice} onChange={(event) => setVoice(event.target.value)} className="mt-2 w-full rounded-xl border border-input bg-background px-3 py-3 text-sm"><option value="en-us">English · neutral</option><option value="en+f2">English · warm</option><option value="en+f3">English · bright</option><option value="en+f5">English · low</option></select></label>
        <div className="mt-4 space-y-2 rounded-xl bg-muted p-3 text-sm"><label className="flex items-center gap-3"><input type="checkbox" checked={includeCaptions} onChange={(event) => setIncludeCaptions(event.target.checked)} />Burn in captions</label><label className="flex items-center gap-3"><input type="checkbox" checked={includeMusic} onChange={(event) => setIncludeMusic(event.target.checked)} />Add local music bed</label></div>
        <button onClick={onGenerate} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-primary-foreground" data-testid="button-confirm-export"><Clapperboard size={15} />Generate final MP4</button>
        <p className="mt-3 text-center font-mono-ui text-[9px] uppercase tracking-wider text-muted-foreground">Local FFmpeg compositor · no paid API key</p>
      </div>
    </div>
  );
}