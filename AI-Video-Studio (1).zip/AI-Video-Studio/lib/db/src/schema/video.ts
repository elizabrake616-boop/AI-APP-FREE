import { relations } from "drizzle-orm";
import {
  integer,
  pgEnum,
  pgTable,
  real,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";

export const projectStatusEnum = pgEnum("project_status", [
  "draft",
  "analyzing",
  "ready",
  "rendering",
  "exported",
]);
export const sceneStatusEnum = pgEnum("scene_status", [
  "draft",
  "generating",
  "ready",
  "error",
]);
export const assetTypeEnum = pgEnum("asset_type", [
  "video",
  "image",
  "audio",
  "music",
  "subtitle",
]);
export const assetSourceEnum = pgEnum("asset_source", ["upload", "generated"]);
export const jobKindEnum = pgEnum("job_kind", [
  "video",
  "voiceover",
  "captions",
  "export",
  "episode",
]);
export const jobStatusEnum = pgEnum("job_status", [
  "queued",
  "processing",
  "complete",
  "failed",
]);

export const projectsTable = pgTable("video_projects", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  story: text("story").notNull().default(""),
  status: projectStatusEnum("status").notNull().default("draft"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  thumbnailUrl: text("thumbnail_url"),
});

export const scenesTable = pgTable("video_scenes", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id")
    .notNull()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  position: integer("position").notNull(),
  description: text("description").notNull(),
  videoPrompt: text("video_prompt").notNull(),
  duration: real("duration").notNull().default(5),
  voiceover: text("voiceover").notNull().default(""),
  assetId: integer("asset_id"),
  status: sceneStatusEnum("status").notNull().default("draft"),
  previewUrl: text("preview_url"),
});

export const assetsTable = pgTable("video_assets", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id")
    .notNull()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  type: assetTypeEnum("type").notNull(),
  mimeType: text("mime_type").notNull(),
  objectPath: text("object_path"),
  source: assetSourceEnum("source").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const jobsTable = pgTable("video_jobs", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id")
    .notNull()
    .references(() => projectsTable.id, { onDelete: "cascade" }),
  kind: jobKindEnum("kind").notNull(),
  sceneId: integer("scene_id").references(() => scenesTable.id, { onDelete: "set null" }),
  provider: text("provider").notNull(),
  status: jobStatusEnum("status").notNull().default("queued"),
  progress: integer("progress").notNull().default(0),
  outputAssetId: integer("output_asset_id"),
  message: text("message").notNull().default("Queued for provider execution."),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const projectsRelations = relations(projectsTable, ({ many }) => ({
  scenes: many(scenesTable),
  assets: many(assetsTable),
  jobs: many(jobsTable),
}));

export const scenesRelations = relations(scenesTable, ({ one }) => ({
  project: one(projectsTable, {
    fields: [scenesTable.projectId],
    references: [projectsTable.id],
  }),
}));

export const assetsRelations = relations(assetsTable, ({ one }) => ({
  project: one(projectsTable, {
    fields: [assetsTable.projectId],
    references: [projectsTable.id],
  }),
}));

export const jobsRelations = relations(jobsTable, ({ one }) => ({
  project: one(projectsTable, {
    fields: [jobsTable.projectId],
    references: [projectsTable.id],
  }),
}));