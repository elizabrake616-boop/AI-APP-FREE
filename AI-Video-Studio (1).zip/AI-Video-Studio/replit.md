# Framewise Video Studio

Framewise is a personal AI-assisted workspace for turning story ideas into editable vertical short-form video projects.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/video-studio/src/` — React dashboard, project archive, and scene editor
- `artifacts/api-server/src/routes/video.ts` — project, scene, asset, generation-job, and export API
- `artifacts/api-server/src/providers/` — replaceable video, voice, captions, and FFmpeg provider seams
- `lib/api-spec/openapi.yaml` — source of truth for the generated API hooks and schemas
- `lib/db/src/schema/video.ts` — PostgreSQL schema for projects, scenes, assets, and jobs
- `artifacts/video-studio/src/index.css` — Framewise visual theme and shared tokens

## Architecture decisions

- Projects and editable scenes persist in PostgreSQL; imported/generated media is represented by asset metadata and an `objectPath` seam.
- Story analysis is deterministic for the first build, splitting prose into scene beats so a real LLM provider can replace it later.
- Video, TTS, captions, and export jobs are queued through one provider interface; the first build reports an honest not-configured state instead of claiming free or unlimited generation.
- The first export target is vertical 9:16 at 720 × 1280 with MP4/FFmpeg as the compositor seam.

## Product

- Dashboard with project summary and recent story cards
- Project archive with search, filtering, create, and delete flows
- Story editor with scene analysis, editable scene description/prompt/duration/voice-over fields, vertical preview, local media import, provider job controls, and export queueing

## User preferences

The user requested a personal-use tool without payment, subscription, or multi-user features.

## Gotchas

- Run `pnpm --filter @workspace/api-spec run codegen` after changing `lib/api-spec/openapi.yaml`.
- Uploaded files currently preview in-browser and persist metadata only; connect App Storage before treating them as durable media.
- Provider jobs are intentionally queued placeholders until real open-source video, TTS, caption, and FFmpeg implementations are connected.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
